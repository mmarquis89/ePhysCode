function tabpanel(figname,tag,action)
%TABPANEL  "TabPanel Constructor" offers the easiest way for creating tabpanels in MATLAB
%  Usage:
%  1. Open the figure (where the tab panel needs to be integrated) in
%     GUIDE and create a Text-Object which reserves the place of the future
%     tabpanel.
%  2. Specify and note the unique tag-name of the created text-object and the
%     figure filename.
%  3. Start "TabPanel Constructor" as follows:
%        >> tabpanel('filename.fig','tabpaneltag')
%
%  Options:
%     a. activate "TabPanel Constructor" to edit an existing tabpanel:
%        >> tabpanel('filename.fig','tabpaneltag') 
%     b. remove tabpanel from GUI
%        >> tabpanel('filename.fig','tabpaneltag','delete')
%
%   Version: v2.3
%   Date:    2008/02/27 00:00:00
%   (c) 2008 By Elmar Tarajan [MCommander@gmx.de]

%
% check if figure file exists
filename = [strrep(figname,'.fig','') '.fig'];
if exist(figname,'file')
   mainfig = openfig(filename,'reuse');
else
   errordlg(sprintf('file ''%s'' not found.',filename),'ERROR','modal')
   return
end% if
%
% check if tag exists
maintab = findobj(mainfig,'tag',tag);
if isempty(maintab)
   errordlg(sprintf('specified UI tag [%s] not found.',tag),'ERROR','modal')
   return
end% if
%
% get the handles of tabpanel parts
tbp = findobj(mainfig,'Tag',['TBP_' tag],'type','uipanel');       % tabpanel
twn = findobj(mainfig,'Tag',['TBP_' tag],'type','uicontrol');     % warning
tpc = findobj(mainfig,'Tag',['TPC_' tag],'type','uipanel');       % constructor
tmn = findobj(mainfig,'Tag',['TPC_' tag],'type','uicontextmenu'); % uimenu
% 
if ~isempty(tbp)
   H = get(tbp,'UserData');
   %
   % check if the TPC must be deleted
   if exist('action','var') && strcmp('delete',action);
      % delete tabpanel & constructor
      delete([tbp twn]) % tabpanel
      if ~isempty(tpc) % constructor
         delete([tpc tmn])
         set(H.Figure,{'Resize' 'Units' 'CloseRequestFcn' 'WindowButtonMotionFcn' 'WindowButtonUpFcn'},H.TPC.Memo)
      end% if
      % make dummy text object visible
      set(maintab,'Visible','on')
      % save restored figure
      hgsave(H.Figure,H.Filename);      
      return
   end
else
   if exist('action','var') && strcmp('delete',action);
      errordlg(sprintf('TabPanel [%s] not exist.',tag),'ERROR','modal')
      return
   end% if
   % set the visibility of dummy object to 'off'.
   set(maintab,'units','pixel','visible','off')
   % get the position of dummy object for the future tabpanel
   pos = get(maintab,'pos');
   %
   % initialize TabPanel / main struct
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   H.Filename  = filename;
   H.Figure    = mainfig;
   H.Tag       = tag;
   H.Location  = pos(1:2);
   H.Size      = pos(3:4);
   H.TabHeight = [14 2 0];
   H.TabDist   = 1;
   H.Count     = 0;
   H.Enable    = 'inactive';
   H.Alignment = 'left' ;
   H.Border    = 'beveledout';
   H.Color     = {get(0,'DefaultUicontrolBackgroundcolor'), ...
                  [.2 .2 .2],[.6 .6 .6],[.9 .9 .9],[1 1 1],[.5 .5 .5]};   
   H.Font      = struct('FontName'  ,get(0,'DefaultUicontrolFontName'), ...
                        'FontUnits' ,get(0,'DefaultUicontrolFontUnits'), ...
                        'FontSize'  ,get(0,'DefaultUicontrolFontSize'), ...
                        'FontWeight',get(0,'DefaultUicontrolFontWeight'), ...
                        'FontAngle' ,get(0,'DefaultUicontrolFontAngle'));
   H.Main      = uipanel('Parent',H.Figure,'Tag',['TBP_' tag], ...
                        'BorderType','none','units','pixel', ...
                        'BackgroundColor','none','pos',[H.Location H.Size]);
   H.Info      = uicontrol('Parent',H.Figure,'Tag',['TBP_' tag],'style','text', ...
                        'units','pixel','pos',[H.Location H.Size], ...
                        'BackgroundColor',[.6 .6 .6],'ForegroundColor',[.9 .9 .9], ...
                        'String',{'' 'TabPanel Constructor v2.3' '(c) 2008'});
   H.Tab       = [];
   H.TopTab    = uicontrol('Parent',H.Main,'visible','off','UserData',0,'style','text','String','');
   H.Panel     = [];
   H.TopPanel  = uipanel('Parent',H.Main,'visible','off','BorderType','none');
   %
end
%
% initialize "TabPanel Constructor" control panel
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if ~isempty(tpc)
   errordlg({'only one instance of "TabPanel Contructor" is allowed.'},'ERROR','modal')
   return
end% if
%
H = CreateTPC(H);
%
if H.Count
   set(H.TPC.main([4 5 6 7 8 9 10]),'enable','on')
   set(H.TPC.main(8),'enable','inactive','ButtonDownFcn',{@Settings,H.Main,'settings'})
end% if
%
% save figure settings
H.TPC.Memo = get(H.Figure,{'Resize' 'Units' 'CloseRequestFcn' ...
                           'WindowButtonMotionFcn' 'WindowButtonUpFcn'});
% disable the the Figure Resizing, set units to pixel and 
set(mainfig,'CloseRequestFcn',{@FigureCloseRequest,H.Main},'Resize','off','Units','pixel')
% save Handles-Struct "H" to userdata
set(H.Main,'UserData',H);
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function EditCurrentPanel(obj,cnc,H)
%-------------------------------------------------------------------------------
H = get(H,'UserData');
% get current panel
ind = get(H.TopPanel,'UserData');
% create unvisible figure
if ~exist(get(H.Tab(ind),'Tag'),'file')
   fig = figure('NumberTitle','off', ...
      'Name',[H.Tag '/' get(H.Tab(ind),'String')], ...
      'Units','pixels', ...
      'Menubar','none', ...
      'color',H.Color{1}, ...
      'position',[H.Location 0 0]+[0 0 H.Size-[0 sum(H.TabHeight)+H.TabDist]], ...
      'visible','off');
   % copy all kids from the current panel into the new created figure
   copyobj(get(H.Panel(ind),'Children'),fig)
   % save unvisible figure as FIG-file
   hgsave(fig,get(H.Tab(ind),'Tag'))
   % delete it
   delete(fig);
end% if
h = guide(get(H.Tab(ind),'Tag'));
% set title (undocumented)
try
   h.setTitle([H.Tag '/' get(H.Tab(ind),'String')])
end% try
drawnow
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function UpdateCurrentPanel(obj,cnc,H)
%-------------------------------------------------------------------------------
H = get(H,'UserData');
% for-loop for all tabs
for fname = cellstr(get(H.Tab,'Tag'))'
   % check if appropriate file exists
   if exist(char(fname),'file')==2
      % determine the tab index
      ind = strcmp(fname,cellstr(get(H.Tab,'Tag')));
      % open FIG-file as unvisible
      fig = openfig(char(fname),'new','invisible');
      %
      % check if identical TAG names are used
      try
         old = get(H.Panel,'Children');
         old(ind) = [];
         new = get(fig,'children');
         even = ismember(get(new,'Tag'),get(cell2mat(old),'Tag'));
         if any(even)
            tmp = cellstr(get(new(even),'Tag'));
            answer = questdlg(sprintf(['%s\nThe above TAG name(s) is(are) already in use.' ...
               ' It is strongly recommended to use unique TAG name(s) for each UI object.\n\n' ...
                'Click "OK" to apply the TAG name(s) anyway.\nClick "Cancel" to return to GUIDE\n\n']', ...
               sprintf('%s\n',tmp{:})),'WARNING','OK','Cancel','Cancel');
            if isempty(answer)
               return
            end% if
            switch answer
               case 'Cancel'
                  EditCurrentPanel([],[],H.Main)
                  return
            end% switch
         end% if
      end% try
      %
      % remove all kids from the panel
      delete(get(H.Panel(ind),'children'))
      drawnow
      % copy UI-objects into the panel
      kids = copyobj(get(fig,'children'),H.Panel(ind));
      % determine UICONTROLS-objects only
      kids = findobj(kids,'type','uicontrol');
      % "Callback"
      if ~isempty(kids)
         if length(kids) == 1
            ind = isempty(get(kids,'Callback'));
         else
            ind = cellfun(@isempty,get(kids,'Callback'));
         end% if
         set(kids(ind),'Callback','%automatic');
         %
         if any(ind)
         kids = kids(ismember(get(kids(ind),'Style'), ...
                     {'listbox' 'popupmenu' 'listbox' 'slider' 'edit'}));
         else
            kids = [];
         end% if
      end% if
      % "CreateFcn"      
      if ~isempty(kids)
         if length(kids) == 1
            ind = isempty(get(kids,'CreateFcn'));
         else
            ind = cellfun(@isempty,get(kids,'CreateFcn'));
         end% if
         set(kids(ind),'CreateFcn','%automatic');
      end% if
      % delete Figure
      delete(fig);
      % delete FIG-file
      delete(char(fname))
      %
   end% if
end% for
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Settings(obj,cnc,H,action,value)
%-------------------------------------------------------------------------------
H = get(H,'UserData');
switch action
   case 'menu'
      switch get(obj,'Label')
         case 'REMOVE current panel'
            answer = questdlg('Are you really sure you want to delete the current panel?', ...
                              'WARNING: Delete current panel','cancel', 'delete', 'cancel');
            if strcmp(answer,'cancel')
               return
            end% if
            ind = get(H.TopPanel,'UserData');
            delete([H.Tab(ind) H.Panel(ind)]);
            H.Tab(ind)      = [];
            H.Panel(ind)    = [];
            H.Count = length(H.Tab);
            set(H.TopPanel,'UserData',1)
            %
            if ~H.Count
               set(H.TPC.main([4 5 6 7 8]),'enable','off')
               set(H.TPC.main(8),'ButtonDownFcn','')
               set(get(H.TPC.cmenu,'children'),'Enable','off')
               set(H.Info,'Visible','on','String',{'' 'TabPanel Constructor v2.3' '(c) 2008'})
               set(H.TopPanel,'Visible','off','UserData',0)
               set(H.Main,'UserData',H)
               return
            end% if
            %
         case 'classic'
            H.Border = 'beveledout';
            H.Alignment = 'left';
            H.Enable = 'inactive';
            H.Color = {get(H.Figure,'Color'),[.2 .2 .2],[.6 .6 .6],[.9 .9 .9],[1 1 1],[.5 .5 .5]};
            H.TabHeight(2:3) = [2 0];
            H.TabDist = 1; 
            %
         case 'modern'
            H.Border = 'none';
            H.Alignment = 'auto';
            H.Enable = 'inactive';
            H.Color = {get(H.Figure,'Color')-[.1 .1 .1],[1 1 1],get(H.Figure,'Color')-[.1 .1 .1],[.2 .2 .2],[1 1 1],[.5 .5 .5]};
            H.TabHeight(2:3) = [0 2];
            H.TabDist = 2;
            %
         case 'discreet'
            H.Border = 'none';
            H.Alignment = 'left';
            H.Enable = 'inactive';
            H.Color = {get(H.Figure,'Color')-[.1 .1 .1],[0 0 0],get(H.Figure,'Color'),[0 0 0],[1 1 1],[.5 .5 .5]};
            H.TabHeight(2:3) = [2 1];
            H.TabDist = 1;
            %
         case 'highlight'
            H.Border = 'line';
            H.Alignment = 'center';
            H.Enable = 'inactive';
            H.Color = {get(H.Figure,'Color'),[1 1 1],get(H.Figure,'Color'),[.2 .2 .2],[1 1 1],[.5 .5 .5]};
            H.TabHeight(2:3) = [2 0];
            H.TabDist = 2;
            %
         case 'inverse'
            H.Border = 'beveledin';
            H.Alignment = 'auto';
            H.Enable = 'off';
            H.Color = {[.8 .8 .8],[.4 .4 .4],get(H.Figure,'Color'),[.2 .2 .2],[1 1 1],[.5 .5 .5]};
            H.TabHeight(2:3) = [2 1];
            H.TabDist = 2;
            %
         case 'borderless'
            H.Border = 'none';
            H.Alignment = 'auto';
            H.Enable = 'inactive';
            H.Color = {[.7 .7 .7],[1 1 1],[.5 .5 .5],[.2 .2 .2],[1 1 1],[.5 .5 .5]};
            H.TabHeight(2:3) = [0 0];
            H.TabDist = 0;
            %
      end% switch
      %
   case 'addpanel'
      warn_msg = '';
      answer = {''};
      while 1
         tmp = {'Label'};
         tmp{1} = sprintf('%s%s',warn_msg,tmp{1});
         answer = inputdlg(tmp,'add new panel',1,answer);
         if isempty(answer)
            return
         elseif isempty(strrep(answer{1},' ',''))
            warn_msg = sprintf('WARNING:\nempty entry as tab title is not allowed\n\n');
         else
            break
         end% if
      end% while
      %
      [cnc internal_tag] = fileparts(tempname);
      if ~isempty(answer)
         H.Count = H.Count + 1;
         H.Panel(H.Count) = uipanel('Parent',H.Main,'visible','off');
         H.Tab(H.Count) = uicontrol('Parent',H.Main,'Tag',[char(internal_tag) '.fig'], ...
            'String',answer{1},'enable','inactive','style','text','visible','off', ...
            'FontAngle' ,H.Font.FontAngle, ...
            'FontWeight',H.Font.FontWeight, ...
            'FontSize'  ,H.Font.FontSize, ...
            'FontName'  ,H.Font.FontName, ...
            'FontUnits' ,H.Font.FontUnits, ...
            'buttondownfcn',[ ...
               'TP_TEMP_VAR.H = get(get(gcbo,''Parent''),''UserData'');' ...
               'TP_TEMP_VAR.old = get(TP_TEMP_VAR.H.TopPanel,''UserData'');' ...
               'if TP_TEMP_VAR.H.Tab(TP_TEMP_VAR.old)~=gcbo;' ...
               '   TP_TEMP_VAR.h = [TP_TEMP_VAR.H.Main TP_TEMP_VAR.H.Panel TP_TEMP_VAR.H.TopPanel TP_TEMP_VAR.H.Tab TP_TEMP_VAR.H.TopTab];' ...
               '   TP_TEMP_VAR.units = get(TP_TEMP_VAR.h,''units'');' ...
               '   set(TP_TEMP_VAR.h,''units'',''pixel'');' ...
               '   TP_TEMP_VAR.p = get(gcbo,''pos'');' ...
               '   TP_TEMP_VAR.pTP = get(TP_TEMP_VAR.H.TopPanel,''pos'');' ...
               '   set(TP_TEMP_VAR.H.Tab(TP_TEMP_VAR.old),''pos'',[TP_TEMP_VAR.pTP(1) TP_TEMP_VAR.p(2) TP_TEMP_VAR.pTP(3) TP_TEMP_VAR.p(4)],''back'',TP_TEMP_VAR.H.Color{3},''fore'',TP_TEMP_VAR.H.Color{4},''enable'',TP_TEMP_VAR.H.Enable);' ...
               '   TP_TEMP_VAR.pP = get(TP_TEMP_VAR.H.Panel(1),''pos'');' ...
               '   set(TP_TEMP_VAR.H.TopPanel,''pos'',[TP_TEMP_VAR.p(1) TP_TEMP_VAR.pP(4) TP_TEMP_VAR.p(3) TP_TEMP_VAR.pTP(4)],''UserData'',find(TP_TEMP_VAR.H.Tab==gcbo));' ...
               '   set(TP_TEMP_VAR.H.TopTab  ,''pos'',[TP_TEMP_VAR.p(1)+1 TP_TEMP_VAR.pP(4) TP_TEMP_VAR.p(3)-2 1]);' ...
               '   set(gcbo,''pos'',TP_TEMP_VAR.p+[1 floor(-diff(TP_TEMP_VAR.H.TabHeight(2:3))/2-.5) -2 0],''back'',TP_TEMP_VAR.H.Color{1},''fore'',TP_TEMP_VAR.H.Color{2},''enable'',''inactive'');' ...
               '   set(TP_TEMP_VAR.h,{''units''},TP_TEMP_VAR.units);' ...
               '   set(TP_TEMP_VAR.H.Panel(TP_TEMP_VAR.H.Tab~=gcbo),''Visible'',''off'');' ...
               '   set(TP_TEMP_VAR.H.Panel(TP_TEMP_VAR.H.Tab==gcbo),''Visible'',''on'');' ...
               '   clear TP_TEMP_VAR;' ...
               '   drawnow;' ...
               'end;']);
         %
         uistack(H.TopPanel,'top')
         set(H.Info,'Visible','off')
         %
         set(H.TPC.main([3 4 5 6 7 8 9 10]),'enable','on')
         set(H.TPC.main(8),'enable','inactive','ButtonDownFcn',{@Settings,H.Main,'settings'})
         set(get(H.TPC.cmenu,'children'),'Enable','on')         
         %
         set(H.TopPanel,'UserData',H.Count)
      end% if
      %
   case 'settings' 
      if strcmp('normal',get(H.Figure,'SelectionType'))
         set(obj,'String','use right button')
         pause(1)
         set(obj,'String','settings')
      end% if
      return      
      %
   case 'move'
      ind = get(H.TopPanel,'UserData');
      id = [1:(ind+value/2-1.5) ind+value/2+0.5 ind+value/2-0.5 ind+(value/2+1.5):H.Count];
      if length(id)==H.Count
         H.Tab      = H.Tab(id);
         H.Panel    = H.Panel(id);
         set(H.TopPanel,'UserData',ind+value)
      end
      %
   case 'Alignment'
      H.Alignment = value;
      %
   case 'Color'
      if value
         H.Color{value} = uisetcolor(H.Color{value});
      else
         H.Color = {[.831 .816 .784],[.2 .2 .2],[.6 .6 .6],[.9 .9 .9],[1 1 1],[.5 .5 .5]};
      end% if
      %
   case 'Enable'
      H.Enable = value;
      %
   case 'Border type'
      H.Border = value;
      %
   case 'Label'
      warn_msg = '';
      answer = cellstr(get(H.Tab,'String')); 
      while 1
         tmp = strcat('Label [',cellstr(get(H.Tab,'String')),']');
         tmp{1} = sprintf('%s%s',warn_msg,tmp{1});
         answer = inputdlg(tmp,'tab labels',1,answer);
         if isempty(answer)
            return
         elseif any(cellfun(@isempty,strrep(answer,' ','')))
            warn_msg = sprintf('WARNING:\nempty entry as tab title is not allowed\n\n');
         else
            break
         end% if
      end% while
      set(H.Tab,{'string'},answer)
      %
   case 'Size'
      answer=inputdlg({'current position (pixel)', ...
                       'tab height', ...
                       'horizontal outbreak [0..10]', ...
                       'horizontaldistance tab<=>tab [0..10]', ...
                       'vertical distance tab<=>panel [0..10]'}, ...
                       'Tab Appearance',1, ...
                      [{sprintf('[%.0f %.0f %.0f %.0f]',H.Location,H.Size)}, ...
                       {num2str(H.TabHeight(1))}, ...
                       {num2str(H.TabHeight(2))}, ...
                       {num2str(H.TabDist)}, ...
                       {num2str(H.TabHeight(3))}]);
      if isempty(answer)
         return
      end% if                    
      pos = str2num(answer{1});
      H.Location  = pos(1:2);
      H.Size      = pos(3:4);
      H.TabHeight = [str2double(answer{2}) max(min(str2double(answer{3}),10),0) max(min(str2double(answer{5}),10),0)];
      H.TabDist   = max(min(str2double(answer{4}),10),0);
      set(H.Main,'units','pixel','pos',[H.Location H.Size]);
      set(H.Info,'units','pixel','pos',[H.Location H.Size]);
      set(H.TPC.Main,'userdata',[H.Location+[(H.Size(1)-158)/2 0] 158 48]);
      %
   case 'Font'
      tmp = uisetfont(H.Font);
      if ~isa(tmp,'struct') ; return ; end
      H.Font = tmp;
      set([H.Tab H.TopTab],'units','pixel',...
         'FontAngle',H.Font.FontAngle, ...
         'FontWeight',H.Font.FontWeight, ...
         'FontSize',H.Font.FontSize, ...
         'FontName',H.Font.FontName, ...
         'FontUnits',H.Font.FontUnits)
      drawnow
      ext = get(H.Tab(1),'extent');
      H.TabHeight = [ext(4)-3 H.TabHeight(2:3)];
end
UpdateTabpanel(H,get(H.TopPanel,'UserData'))
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function UpdateTabpanel(H,ind)
%-------------------------------------------------------------------------------
%
set([H.Main H.Info H.Panel H.TopPanel H.Tab H.TopTab],'Units','pixel')
if H.Count == 1
   pos = get(H.Tab,'extent');
else
   pos = cell2mat(get(H.Tab,'extent'));
   pos(:,3) = max(pos(:,3),15);
end% if
%
pos(:,4) = H.TabHeight(1);
pos(:,2) = H.Size(2)-sum(H.TabHeight(1:2));
%
tmp = (H.Size(1)-(H.Count-1)*H.TabDist);
if any(strcmp(H.Alignment,{'auto' 'equal'}))
   switch H.Alignment
      case 'auto'; pos(:,3) = round(pos(:,3)*tmp/sum(pos(:,3)));
      case 'equal';pos(:,3) = repmat(round(tmp/H.Count),H.Count,1);
   end% switch
   pos(end,3) = pos(end,3)+H.Size(1)-sum(pos(:,3))-(H.Count-1)*H.TabDist;
end% if
if sum(pos(:,3))>H.Size(1)
   H.Alignment = 'auto';
   UpdateTabpanel(H,ind)
   return
end% if
switch H.Alignment
   case 'center'
      tmp = round((H.Size(1)-sum(pos(:,3))-(H.Count-1)*H.TabDist)/2);
   case 'right'
      tmp = H.Size(1)-sum(pos(:,3))-(H.Count-1)*H.TabDist;
   otherwise
      tmp = 0;
end% switch
pos(:,1) = cumsum([tmp+1;pos(1:end-1,3)+H.TabDist]);
%
pos = mat2cell(pos,ones(1,H.Count),4);
%
cfg.visible = 'on';
cfg.back    = H.Color{1};
cfg.fore    = H.Color{2};
set(H.Tab,cfg,{'pos'},pos,'back',H.Color{3},'fore',H.Color{4},'enable',H.Enable)
set(H.Tab(ind),cfg,'pos',pos{ind}+[1 floor(-diff(H.TabHeight(2:3))/2-.5) -2 0],'enable','inactive');
set(H.TopTab,cfg,'pos',[pos{ind}(1)+1 H.Size(2)-sum(H.TabHeight)-1 pos{ind}(3)-2 1])
cfg.BorderType = H.Border;
cfg.HighlightColor = H.Color{5};
cfg.ShadowColor = H.Color{6};
set(H.TopPanel,cfg,'UserData',ind,'pos',[pos{ind}(1) H.Size(2)-sum(H.TabHeight)-1 pos{ind}(3) sum(H.TabHeight)+1])
set(H.Panel,cfg,'visible','off','pos',[1 1 H.Size-[0 sum(H.TabHeight)+1]])
set(H.Panel(ind),cfg)
%
set(H.Main,'UserData',H)
%
set([H.Main H.Info H.Panel H.TopPanel H.Tab H.TopTab],'Units','normalized')
drawnow
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function TPCDragNDrop(hObj,cnc,action,hup,pos)
%-------------------------------------------------------------------------------
switch action
   case 'down'
      pos = get(hup,'position');
      set(gcbf,'WindowButtonMotionFcn',{@TPCDragNDrop,'move',hup,[get(gcbf,'CurrentPoint')-pos(1:2) pos(3:4)]}, ...
               'WindowButtonUpFcn',{@TPCDragNDrop,'up',hup})
   case 'move'
      set(hup,'position',[get(gcbf,'CurrentPoint')-pos(1:2) pos(3:4)])
      drawnow
   case 'up'
      set(gcbf,'WindowButtonMotionFcn','','WindowButtonUpFcn','')
      tpcpos = get(hup,'Position');
      figpos = get(hObj,'Position');
      if tpcpos(1)+158>figpos(3) || tpcpos(1)<1 || tpcpos(2)<1 || tpcpos(2)+36>figpos(4)
         set(hup,'position',get(hup,'UserData'))
      end% if
end% switch
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function H = CreateTPC(H)
%-------------------------------------------------------------------------------
H.TPC.Main = uipanel('Parent',H.Figure,'BorderType','none','units','pixel','tag',['TPC_' H.Tag], ...
             'BackgroundColor','none','pos',[H.Location+[(H.Size(1)-158)/2 -18] 158 48], ...
             'UserData',[H.Location+[(H.Size(1)-158)/2 -18] 158 48]);
%
cfg.parent   = H.TPC.Main;
cfg.units    = 'pixel';
cfg.fontSize = 7;
cfg.enable   = 'on';
cfg.value    = 1;
cfg.style    = 'popupmenu';
cfg.enable   = 'off';
%
H.TPC.main(1)=uicontrol(cfg,'style','text','back',[.35 .35 .35],'for',[.7 .7 .7],'enable','off','pos',[-2 -2 164 51], ...
   'string',' TPC v2.3','FontSize',7,'HorizontalAlignment','left','ButtonDownFcn',{@TPCDragNDrop,'down',H.TPC.Main});
H.TPC.main(2) = uicontrol(cfg,'style','edit','enable','off','pos',[1 1 158 36],'visible','on');
cfg.style           = 'pushbutton';
cfg.foregroundcolor = [0.3 0.3 0.3];
cfg.cdata           = repmat(repmat(linspace(.6,1,12)',1,55),[1 1 3]);
H.TPC.main(3) = uicontrol(cfg,'String','add panel','ToolTipString','add new tabpanel', ...
   'Callback',{@Settings,H.Main,'addpanel'},'enable','on','pos',[3 19 59 16]);
cfg.cdata           = repmat(repmat(linspace(.6,1,12)',1,26),[1 1 3]);
H.TPC.main(4) = uicontrol(cfg,'String','<<','ToolTipString','move left', ...
   'Callback',{@Settings,H.Main,'move',-1},'pos',[3 3 30 16]);
cfg.cdata           = repmat(repmat(linspace(.6,1,12)',1,26),[1 1 3]);
H.TPC.main(5) = uicontrol(cfg,'String','>>','ToolTipString','move right', ...
   'Callback',{@Settings,H.Main,'move',+1},'pos',[32 3 30 16]);
cfg.cdata        = repmat(repmat(linspace(.6,1,12)',1,36),[1 1 3]);
cfg.cdata(:,:,1) = cfg.cdata(:,:,1).*.9;
cfg.cdata(:,:,2) = cfg.cdata(:,:,2).*1;
cfg.cdata(:,:,3) = cfg.cdata(:,:,3).*.9;
H.TPC.main(6) = uicontrol(cfg,'String','edit','ToolTipString','open guide to edit tabpanel', ...
   'Callback',{@EditCurrentPanel,H.Main},'pos',[62 19 40 16]);
cfg.cdata        = repmat(repmat(linspace(.6,1,12)',1,36),[1 1 3]);
cfg.cdata(:,:,1) = cfg.cdata(:,:,1).*1;
cfg.cdata(:,:,2) = cfg.cdata(:,:,2).*.9;
cfg.cdata(:,:,3) = cfg.cdata(:,:,3).*.9;
H.TPC.main(7) = uicontrol(cfg,'String','update','ToolTipString','update tabpanel(s)', ...
   'Callback',{@UpdateCurrentPanel,H.Main},'pos',[101 19 40 16]);
cfg.cdata        = repmat(repmat(linspace(.6,1,12)',1,76),[1 1 3]);
cfg.cdata(:,:,1) = cfg.cdata(:,:,1).*1;
cfg.cdata(:,:,2) = cfg.cdata(:,:,2).*1;
cfg.cdata(:,:,3) = cfg.cdata(:,:,3).*.9;
H.TPC.cmenu = uicontextmenu('Parent',H.Figure,'Tag',['TPC_' H.Tag]);
H.TPC.main(8) = uicontrol(cfg,'String','settings','pos',[62 3 79 16], ...
   'uicontextmenu',H.TPC.cmenu,'TooltipString','use right mouse button');
cdata = repmat( repmat(linspace(.6,1,12)',1,12),[1 1 3]);
H.TPC.main(9) = uicontrol(cfg,'pos',[141 19 16 16],'Enable','on', ...
   'TooltipString','move tpc via drag''n''drop','cdata',cdata,'String','x','FontWeight','bold', ...
   'callback',{@FigureCloseRequest,H.Main});
H.TPC.main(10) = uicontrol(cfg,'pos',[141 3 16 16],'Enable','on', ...
   'TooltipString','about...''n''drop','cdata',cdata,'String','i','FontWeight','bold', ...
   'callback',@TPCinfo);
uimenu(H.TPC.cmenu,'Label','Panel labels','Callback',{@Settings,H.Main,'Label'});
uimenu(H.TPC.cmenu,'Label','Size','Callback',{@Settings,H.Main,'Size'});
tmp = uimenu(H.TPC.cmenu,'Label','Default Styles','Separator','on');
uimenu(tmp,'Label','classic','Callback',{@Settings,H.Main,'menu'});
uimenu(tmp,'Label','modern','Callback',{@Settings,H.Main,'menu'});
uimenu(tmp,'Label','discreet','Callback',{@Settings,H.Main,'menu'});
uimenu(tmp,'Label','highlight','Callback',{@Settings,H.Main,'menu'});
uimenu(tmp,'Label','inverse','Callback',{@Settings,H.Main,'menu'});
uimenu(tmp,'Label','borderless','Callback',{@Settings,H.Main,'menu'});
tmp = uimenu(H.TPC.cmenu,'Label','Alignment');
uimenu(tmp,'Label','left','Callback',{@Settings,H.Main,'Alignment','left'});
uimenu(tmp,'Label','right','Callback',{@Settings,H.Main,'Alignment','right'});
uimenu(tmp,'Label','center','Callback',{@Settings,H.Main,'Alignment','center'});
uimenu(tmp,'Label','equal','Callback',{@Settings,H.Main,'Alignment','equal'});
uimenu(tmp,'Label','auto','Callback',{@Settings,H.Main,'Alignment','auto'});
tmp = uimenu(H.TPC.cmenu,'Label','Color');
uimenu(tmp,'Label','background for active panel','Callback',{@Settings,H.Main,'Color',1});
uimenu(tmp,'Label','foreground for active panel','Callback',{@Settings,H.Main,'Color',2});
uimenu(tmp,'Label','background for inactive panel','Callback',{@Settings,H.Main,'Color',3});
uimenu(tmp,'Label','foreground for inactive panel','Callback',{@Settings,H.Main,'Color',4});
uimenu(tmp,'Label','"disable" inactive panels','Callback',{@Settings,H.Main,'Enable','off'},'separator','on');
uimenu(tmp,'Label','"enable" inactive panels','Callback',{@Settings,H.Main,'Enable','inactive'});
uimenu(tmp,'Label','set default colors','Callback',{@Settings,H.Main,'Color',0},'separator','on');
tmp = uimenu(H.TPC.cmenu,'Label','Border type');
uimenu(tmp,'Label','beveledout','Callback',{@Settings,H.Main,'Border type','beveledout'});
uimenu(tmp,'Label','beveledin','Callback',{@Settings,H.Main,'Border type','beveledin'});
uimenu(tmp,'Label','line','Callback',{@Settings,H.Main,'Border type','line'});
uimenu(tmp,'Label','none','Callback',{@Settings,H.Main,'Border type','none'});
uimenu(tmp,'Label','border highlight color','Callback',{@Settings,H.Main,'Color',5},'separator','on');
uimenu(tmp,'Label','border shadow color','Callback',{@Settings,H.Main,'Color',6});
uimenu(H.TPC.cmenu,'Label','Font','Callback',{@Settings,H.Main,'Font','Font settings'});
uimenu(H.TPC.cmenu,'Label','REMOVE current panel','Callback',{@Settings,H.Main,'menu'},'Separator','on');
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function FigureCloseRequest(obj,cnc,H)
%-------------------------------------------------------------------------------
tmp = strcmp('uicontrol',get(obj,'type'));
%
H = get(H,'UserData');
%
answer = questdlg(sprintf(['Are you really sure you want to close the TabPanel Constructor?\n\n'...
   '"Cancel" to continue the work\n' ...
   '"Close TPC" to save changes and close the TabPabel Constructor\n']), ...
   'Close Request', ...
   'Cancel','Close TPC','Cancel');
%
switch answer
   case 'Close TPC'
      if ~isempty(H.Tab)
         UpdateCurrentPanel([],[],H.Main)
         %
         % prepare GUIDE warning message
         set(H.Info,'BackgroundColor',[.3 .3 .3],'foregroundcolor',[.9 .9 .9], ...
            'String',{repmat('-',1,30) '- WARNING -' repmat('-',1,30) ...
            'use "TabPanel Constructor 2.3" for editing' '' ['>> tabpanel(''' H.Filename ''',''' H.Tag ''')']})
         %
         % remove temporary data
         set(H.Main,'UserData',rmfield(H,'TPC'));
      else
         % delete tabpanel
         delete(findobj(H.Figure,'Tag',['TBP_' H.Tag]))
         set(findobj(H.Figure,'Tag',H.Tag),'Visible','on')
         %
      end% if
      % delete TPC
      delete(findobj(H.Figure,'Tag',['TPC_' H.Tag]))
      % restore saved figure settings
      set(H.Figure,{'Resize' 'Units' 'CloseRequestFcn' 'WindowButtonMotionFcn' 'WindowButtonUpFcn'},H.TPC.Memo)
      % prepare FIG-file bevor saving (undocumented)
      setappdata(H.Figure,'GUIDEOptions',guideopts(H.Figure))
      % update M-File with callbacks (undocumented)
      opts = guideopts(H.Figure);
      [cnc fname cnc] = fileparts(opts.lastSavedFile(1:end-1));
      opts = setfield(opts,'lastFilename',fullfile(cd,[fname '.fig']));
      guideopts(H.Figure,opts)      
      guidemfile('updateFile',H.Figure,H.Filename);
      % save and delete Figure
      hgsave(H.Figure,H.Filename);
      delete(H.Figure)
      %
      if tmp
         openfig(H.Filename)
      end% if
      %
end% switch
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function TPCinfo(obj,cnc)
%-------------------------------------------------------------------------------
answer = questdlg({'TabPanel Contructor v2.3' ...
   '(c) 2008 by Elmar Tarajan [MCommander@gmx.de]'}, ...
   'about...','look for updates','Bug found?','OK','OK');
switch answer
   case 'look for updates'
      web(['http://www.mathworks.com/matlabcentral/fileexchange/' ...
         'loadAuthor.do?objectId=936824&objectType=author'],'-browser');
   case 'Bug found?'
      web(['mailto:MCommander@gmx.de?subject=TPC%20v2.3-BUG:' ...
         '[Description]-[ReproductionSteps]-[Suggestion' ...
         '(if%20possible)]-[MATLAB%20v' strrep(version,' ','%20') ']']);
   case 'OK',
end% switch
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% I LOVE MATLAB %%%