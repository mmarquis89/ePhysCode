function tabpanel(figname,tag,action)
%TABPANEL  "TabPanel Constructor" offers the easiest way for creating tabpanels in MATLAB
%  Usage:
%  1. Open the figure (where the tab panel needs to be integrated) in
%     GUIDE and create a Text-Object which reserves the place of the future
%     tabpanel.
%  2. Specify and note the unique tag-name of the created text-object and the
%     figure filename.
%  3. Start "TabPanel Constructor" as follows:
%        >> tabpanel('filename.fig','tabpaneltag')
%
%  Options:
%     a. activate "TabPanel Constructor" to edit an existing tabpanel:
%        >> tabpanel('filename.fig','tabpaneltag') 
%     b. remove tabpanel from GUI
%        >> tabpanel('filename.fig','tabpaneltag','delete')
%
% See also TABSELECTIONFCN.
% 
%   Version: v2.6
%      Date: 2008/09/26 00:00:00
%   (c) 2008 By Elmar Tarajan [MCommander@gmx.de]

%   2008/09/10 "tabselectionfcn" for programatically tab switching added
%   2008/08/03 TabSelectionChange_Callback added
%   2008/07/02 supporting of nested tabpanels
%   2008/06/23 works now with R14/SP1/SP2/SP3 versions
%   2008/05/08 many code improvements
%   2008/04/16 improved look - using the mouse on "settings"-button
%   2008/03/28 some code improvements
%   2008/03/17 improved look of tabs

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% I LOVE MATLAB! You too? :) %%%